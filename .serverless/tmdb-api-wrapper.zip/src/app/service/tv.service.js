const axios = require("axios");
const buildTv = require("../builders/tv.builder");
const TMDBAPIException = require("../utils/Exceptions");
const TmdbConfig = require("../utils/TmdbConfig");

const getTmdbTv = async (tmdb_id) => {
  const url = `${TmdbConfig.tmdbApiUrl}tv/${tmdb_id}?api_key=${TmdbConfig.tmdbApiKey}&append_to_response=watch/providers,credits,content_ratings`;

  try {
    const { data } = await axios.get(url);
    return buildTv(data);
  } catch (error) {
    if (axios.isCancel(error)) {
      // do nothing
    } else {
      if (error?.response?.data) {
        throw new TMDBAPIException(`${tmdb_id}, ${error.response.data.status_message}`, 409, "", "");
      } else {
        throw error;
      }
    }
  }
};

module.exports = { getTmdbTv };